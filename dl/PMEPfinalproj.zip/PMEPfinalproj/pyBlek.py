#pyBlek.py

#Miles Morin & Emilio Pallares
#COM 110
#Prof. Chung
#12/19/16

#Plays a simpler version of the game Blek for touchscreen devices. Probably works better on PC

from graphics import *
import math
from random import *
import sys
from time import sleep

class PyBlek:

    def __init__(self, s):

        self.s = s
        self.win = GraphWin("pyBlek", self.s/2,self.s/2)
        self.win.setCoords(0,0,self.s,self.s)

        """Start screen"""
        self.win.setBackground("black")

        text = Text(Point(self.s/2, 0.9*self.s), "pyBlek")
        text.setFill("blue")
        text.setSize(36)
        text.draw(self.win)

        how = Text(Point(self.s/2, self.s/2), "Please see instructions.txt for how to play")
        how.setFill("green")
        how.draw(self.win)
        play = Button(self.win, self.s/5, self.s/5, Point(self.s/2, 3*self.s/4), "Play", "blue")
        qui = Button(self.win, self.s/5,self.s/5, Point(self.s/2, self.s/3), "Quit", "Orange")
        
        """"""

        """Get clicks until a button is clicked"""
        pt = self.win.checkMouse()

        while 1: #animates the start screen
            while pt == None or (not play.isClicked(pt) and not qui.isClicked(pt)):
                text.undraw()
                text.draw(self.win)
                randx = randrange(200,1000)
                randy = randrange(200,400)
                if text.getAnchor().getX() > self.s/2 and text.getAnchor().getY() > self.s/2: #divide the window into quadrants
                    for i in range(100):
                        sleep(.000000000000000000000001)
                        text.move(0-self.s/randx, 0-self.s/randy)
                        if play.isClicked(text.getAnchor()):
                            self.blinkButt(play, "blue", "cyan")
                            text.undraw()
                            text.draw(self.win)
                    sleep(.5)
                elif text.getAnchor().getX() < self.s/2 and text.getAnchor().getY() > self.s/2:
                    for i in range(100):
                        sleep(.000000000000000000000000001)
                        text.move(self.s/randx, 0-self.s/randy)
                        if play.isClicked(text.getAnchor()):
                            self.blinkButt(play, "blue", "cyan")
                            text.undraw()
                            text.draw(self.win)
                    sleep(.5)
                elif text.getAnchor().getX() < self.s/2 and text.getAnchor().getY() < self.s/2:
                    for i in range(100):
                        sleep(.0000000000000000000000001)
                        text.move(self.s/randx, self.s/randy)
                        if play.isClicked(text.getAnchor()):
                            self.blinkButt(play, "blue", "cyan")
                            text.undraw()
                            text.draw(self.win)
                    sleep(.5)
                elif text.getAnchor().getX() > self.s/2 and text.getAnchor().getY() < self.s/2:
                    for i in range(100):
                        sleep(.0000000000000001)
                        text.move(0-self.s/randx, self.s/randy)
                        if text.getAnchor() == play.centerPt:
                            self.blinkButt(play, "blue", "cyan")
                            text.undraw()
                            text.draw(self.win)
                    sleep(.5)
                else:
                    text.move(1,0)
                    if text.getAnchor() == play.centerPt:
                        self.blinkButt(play, "blue", "cyan")
                        text.undraw()
                        text.draw(self.win)
                pt = self.win.checkMouse()
            if play.isClicked(pt):
                self.play()
##            elif how.isClicked(pt):
##                os.startfile("instructions.txt")
            else:
                self.win.close()
                sys.exit()

    def play(self):

        """Plays the game"""

        """Create new self.win to play in"""
        self.win.close()
        self.win = GraphWin("pyBlek", self.s,self.s)
        self.win.setCoords(0,0, self.s,self.s)
        self.win.setBackground("cyan")
        """"""

        s = 25 #Side length of squares in pixels

        """Pseudorandomly decide where black squares will be"""
        blacks = [] #List of midpoints of black squares
        blackCt = 0 #Accumulator for counting how many black sqaures currently exist
        desBlackNum = randrange(10,20) #Desired number of black squares. Increasing this number makes the game more difficult
        breaker = 0 #Just in case the board runs out of room
        
        while blackCt < desBlackNum:
            pt = Point(randrange(self.s), randrange(self.s))
            while pt in blacks:
                pt = Point(randrange(self.s), randrange(self.s))
            while not self.isValidBlack(pt, blacks, s) and breaker < 500:
                pt = Point(randrange(self.s), randrange(self.s))
                breaker += 1
            if breaker == 500:
                blackCt = desBlackNum
            else:
                breaker = 0
                blacks.append(pt)
                blackCt += 1
        """"""

        """Pseudorandomly decide which points will be blue squares"""
        blues = [] #List of midpoints of blue squares
        blueCt = 0 #Accumulator for counting how many blue squares currently exist
        desBlueNum = 4 #Desired number of blue squares. Increasing this number makes the game more difficult
        breaker = 0 #Just in case the board runs out of room

        while blueCt < desBlueNum:
            pt = Point(randrange(self.s), randrange(self.s))
            while not self.isValidBlue(pt, blacks, blues, s)[0] and breaker < 500:
                pt = Point(randrange(self.s), randrange(self.s))
                breaker += 1
            if breaker == 500:
                blueCt = desBlueNum
            else:
                blues.append(pt)
                blueCt += 1
        """"""

        blueSqs = [] #List of blue squares
        blackSqs = [] #List of black squares
        blueButts = [] #List of buttons under blue squares
        blackButts = [] #List of buttons under black squares

        """Draw black sqaures on top of their respective buttons"""
        for pt in blacks:
            sq = Rectangle(Point(pt.getX()-(self.s/(s*2)), pt.getY()-(self.s/(s*2))), Point(pt.getX()+(self.s/(s*2)), pt.getY()+(self.s/(s*2))))
            sq.setFill("black")
            butt = Button(self.win, self.s/s, self.s/s, pt, "", "red")
            sq.draw(self.win)
            blackSqs.append(sq)
            blackButts.append(butt)
        """"""

        """Draw blue squares on top of their respective buttons"""
        for pt in blues:
            sq = Rectangle(Point(pt.getX()-(self.s/(s*2)), pt.getY()-(self.s/(s*2))), Point(pt.getX()+(self.s/(s*2)), pt.getY()+(self.s/(s*2))))
            sq.setFill("blue")
            butt = Button(self.win, self.s/s, self.s/s, pt, "", "red")
            sq.draw(self.win)
            blueSqs.append(sq)
            blueButts.append(butt)
        """"""

        butts = blueButts + blackButts #Get a list of all buttons that exist on the board

        """Determine difficulty level of the board out of 10"""
        d = 0 #Accumulator for total distance around the midpoints of the blue squares
        
        for loc in range(len(blues)-1): #Finds distance around the midpoints of the blue squares on the board
            d += self.dist(blues[loc], blues[loc+1])
        d += self.dist(blues[len(blues)-1], blues[0])
        ###

        diffP = (d/(self.s*len(blues)/5))*4 #The distance around the polygon that the midpoints of the blue squares make is worth 5 points out of 10

        dist = 0 #Accumulator for total distance each blue square midpoint is away from its closest black square midpoint
        for pt in blues:
            if len(self.isValidBlue(pt, blacks, blues, s)) == 1:
                pass
            else:
                dist += self.isValidBlue(pt, blacks, blues, s)[1]
        diffD = (dist/(self.s*len(blues)/10))*6

        diff = int(diffP + diffD)

        """"""
        
        """Have the user draw their desired sequence with mouse clicks and draw trailing lines"""
        var = Text(Point(self.s/2, 0.9*self.s), "Click within the space between squares to begin drawing...")
        var.setFill("red")
        var.draw(self.win)
        pt = self.win.getMouse() #Get mouse clicks until the user clicks somewhere valid
        while not self.isValidMouse(pt,butts)[0]:
            pt = self.win.getMouse()
        var.undraw()
        userPts = [] #To store where the user has made valid clicks

        """Add point to userPts and draw it"""
        userPts.append(pt)
        pt.setFill("red")
        pt.draw(self.win)
        """"""

        """Create a mini window that shows how many clicks the user has left"""
        remWinS = 100
        remWin = GraphWin("Clicks remaining", remWinS,remWinS)
        remWin.setCoords(0,0,remWinS,remWinS)
        rem = Text(Point(remWinS/2, 0.75*remWinS), "5")
        rem.setSize(20)
        rem.setFill("green")
        rem.draw(remWin)
        invalid = Text(Point(remWinS/2, remWinS/4), "Invalid Click")
        invalid.setFill("red")
        """"""
        
        lines = [] #To store the initial lines
        
        for click in range(5): #Takes more clicks, draws trailing lines, and stores the clicks and lines in their respective lists
            temppt = pt
            pt = self.win.getMouse()
            while not self.isValidLine(Line(temppt, pt), butts)[0]:
                invalid.draw(remWin)
                sleep(1)
                invalid.undraw()
                pt = self.win.getMouse()

            rem.setText(str(4-click))
            if click == 2:
                rem.setFill("red")
                
            userPts.append(pt)
            pt.setFill("red")
            pt.draw(self.win)

            line = Line(temppt,pt)
            line.setFill("red")
            line.draw(self.win)
            lines.append(line)

        remWin.close() #remWin is no longer needed
        """"""

        """Redraw figure as many times as necessary and either win or lose"""
        """Using booleans referenced in a while loop, create lists of new points and new lines based on the dx's and dy's of the user-determined points"""
        lost = False
        won = False
        use = 0
        newPts = []
        newLines = []
        popCtr = 0
        while not lost and popCtr < len(blues):
            if use == 0:
                newPts.append(userPts[-1]) #the last point the user clicked becomes the new starting point
            else:
                userPts = newPts
                newPts = []
                newPts.append(line.getP2()) #the last point that was drawn becomes the new starting point
                lines = newLines
                newLines = []
                
            for pt in range(len(lines)):
                if popCtr >= len(blues):
                    break
                newPts.append(Point(newPts[pt].getX() + userPts[pt+1].getX() - userPts[pt].getX(), \
                newPts[pt].getY() + userPts[pt+1].getY() - userPts[pt].getY()))
            use = 1
            if popCtr >= len(blues):
                break
            """"""

            for pt in range(len(lines)): #For loop that draws lines and checks if they hit anything
                if not lost:
                    sleep(0.5)
                    line = Line(newPts[pt],newPts[pt+1])
                    line.setFill("red")
                    newLines.append(line)
                    if (not self.isValidLine(newLines[pt], blackButts)[0] or newPts[pt].getX() > self.s or newPts[pt].getY() > self.s or \
                            userPts[pt].getX() > self.s or userPts[pt].getY() > self.s or userPts[pt].getX() < 0 or userPts[pt].getY() < 0 or \
                            newPts[pt].getX() < 0 or newPts[pt].getY() < 0) and popCtr < 4:
                        if not self.isValidLine(newLines[pt], blackButts)[0]:
                            line.draw(self.win)
                            blackButts[self.isValidLine(newLines[pt], blackButts)[1]].rect.undraw()
                            blackButts[self.isValidLine(newLines[pt], blackButts)[1]].label.undraw()
                            blinkSqP1 = blackSqs[self.isValidLine(newLines[pt], blackButts)[1]].getP1()
                            blinkSqP2 = blackSqs[self.isValidLine(newLines[pt], blackButts)[1]].getP2()
                            for i in range(5):
                                rect = Rectangle(blinkSqP1,blinkSqP2)
                                rect.setFill("black")
                                rect.draw(self.win)
                                sleep(.3)
                                rect = Rectangle(blinkSqP1,blinkSqP2)
                                rect.setFill("red")
                                rect.draw(self.win)
                        lost = True #The user loses
                    else:
                        if popCtr >= desBlueNum:
                            break
                        line.draw(self.win)
                        for sq in blueSqs:
                            while not self.isValidLine(line, blueButts)[0]:
                                self.pop(blueSqs, blueButts, self.isValidLine(line, blueButts)[1])
                                popCtr += 1      
                        if popCtr >=desBlueNum:
                            won = True #The user wins
        """"""
        
        sleep(2)

##        """Calculate stats"""
##        prevDiffFile = open("avgdiff.txt", "r")
##        prevDiff = prevDiffFile.read()
##        prevDiffFile.close()
##        prevDiffFile = open("avgdiff.txt", "w")
##        prevDiffFile.seek(0)
##        prevDiffFile.truncate()
##        print(prevDiff)
##        newDiff = (diff+int((prevDiff)))/2
##        prevDiffFile.write(str(newDiff))
##        prevDiffFile.close()
##
##        prevGamesFile = open("games.txt", "r")
##        prevGames = prevGamesFile.read()
##        prevGamesFile.close()
##        prevGamesFile = open("games.txt", "w")
##        prevGamesFile.seek(0)
##        prevGamesFile.truncate()
##        newGames = 1+int(prevGames)
##        prevGamesFile.write(str(newGames))
##
##        prevWinrFile = open("winr.txt", "r")
##        prevWinr = prevWinrFile.read()
##        prevWinrFile.close()
##        prevWinrFile = open("winr.txt", "w")
##        prevWinrFile.seek(0)
##        prevWinrFile.truncate()
##        if int(prevWinr) == 0:
##            if won == True:
##                newWinr = 1
##        else:
##            if won == True:
##                newWinr = (eval((prevWinr))*int(prevGames) + 1)/newGames
##            else:
##                newWinr = (eval((prevWinr))*int((prevGames)))/newGames
##        prevWinrFile.write(str(newWinr))
##        prevWinrFile.close()
##
##        """"""
        
        wonWin = GraphWin("", 3*self.s/4,3*self.s/4)
        wonWin.setCoords(0,0,self.s,self.s)
        wonWin.setBackground("black")
        newGame = Button(wonWin, self.s/10,self.s/3, Point(self.s/2,0.9*self.s),"New Game", "green")
        qui = Button(wonWin, self.s/15,self.s/10, Point(self.s/10,self.s/10),"Quit", "orange")

        hasWon = Text(Point(self.s/2, 2*self.s/3), "You won!")
        hasWon.setFill("green")
        hasWon.setSize(20)
        hasLost = Text(Point(self.s/2, 2*self.s/3), "You lost :(")
        hasLost.setSize(20)
        hasLost.setFill("red")
        if popCtr >= len(blues):
            hasWon.draw(wonWin)
        else:
            hasLost.draw(wonWin)
        text = Text(Point(self.s/2,self.s/2),"The difficulty of that board is "+str(diff)+" out of 10.")
        text.setFill("white")
        text.setSize(13)
        text.draw(wonWin)
        thanks = Text(Point(self.s/2,self.s/3),"Thanks for playing!")
        thanks.setSize(16)
        thanks.setFill("cyan")
        thanks.draw(wonWin)
##        text = Text(Point(self.s/2,self.s/3),"The average difficulty of boards generated has been "+str(newDiff))
##        text.setFill("red")
##        text.setSize(13)
##        text.draw(self.win)
##        text = Text(Point(self.s/2,self.s/4), "Your win/loss ratio is "+str(newWinr)+".")
##        text.setFill("green")
##        text.setSize(13)
##        text.draw(self.win)
##        text = Text(Point(self.s/2, self.s/5), "You've played "+str(newGames)+" games!")

        pt = wonWin.getMouse()
        while not newGame.isClicked(pt) and not qui.isClicked(pt):
            pt = wonWin.getMouse()

        if newGame.isClicked(pt):
            wonWin.close()
            self.play()
##        elif stats_reset.isClicked(pt):
##            statsText = 
        else:
            wonWin.close()
            self.win.close()
            sys.exit()

    def blinkButt(self, butt, origC, blinkC):

        """Blinks a button"""

        butt.rect.undraw()
        butt.rect.setFill(blinkC)
        butt.rect.draw(self.win)
        sleep(.00000001)
        butt.rect.undraw()
        butt.rect.setFill(origC)
        butt.rect.draw(self.win)

        butt.label.undraw()
        butt.label.draw(self.win)

    def dist(self, pt1, pt2):
        """Cartesian distance formula to return the distance between two points"""
        return math.sqrt((pt2.getX() - pt1.getX())**2 + (pt2.getY() - pt1.getY())**2)

    def isValidLine(self, line, butts):

        """Returns a boolean of whether or not a user-drawn line intersects a square on the board. Done by cutting the line into inc number of pieces"""

        """Append extreme points and midpoint to a list"""
        l = []
        l.append(line.getP1())
        l.append(line.getP2())
        l.append(line.getCenter())
        """"""

        inc = 400 #Sets the increment by which the for loop will slide along the line to append points to test. Increasing this number slows the game

        """Append more unique points on the line to the list"""
        """Calculate x and y increments"""
        xInc = (line.getP2().getX() - line.getP1().getX())/inc
        yInc = (line.getP2().getY() - line.getP1().getY())/inc
        """"""

        """2 dimensional accumulation to slide along the line in fractions of its d(x,y)"""
        tempx = line.getP1().getX()
        tempy = line.getP1().getY()
        """"""

        """Take an increment and an extreme value on the line and append inc number of points to the list by adding inc fractions of d(x,y)"""
        for i in range(inc):
            tempx += xInc
            tempy += yInc
            l.append(Point(tempx,tempy))
        """"""

        """Using a boolean, see if any points in the list click any of the buttons under the squares on the board"""
        boo = False
        for pt in l:
            if not self.isValidMouse(pt, butts)[0]:
                ind = self.isValidMouse(pt, butts)[1]
                boo = True
                break
        if boo:
            return [False, ind]
        else:
            return [True]

    def isValidMouse(self, pt, butts):

        """Using butt.isClicked(pt), returns a boolean of whether or not a point is on a square on the board. Returns false pt is outside of self.win"""

        ind = -1
        boo = False
        for butt in butts:
            ind += 1
            if butt.isClicked(pt):
                boo = True
                break
        if boo:
            return [False, ind]
        else:
            return [True]

    def isValidBlack(self, pt, blacks, sqS):

        """Returns a boolean of whether or not a point can be used as the midpoint of a black square"""

        """Create a sorted list of distances between pt and black squares"""
        l = []
        for point in blacks:
            l.append(self.dist(pt,point))
        l = sorted(l)
        """"""

        """Verify that pt is far enough away from the midpoint of the black square that it's closest to"""
        """Calculate desired minimum distance away from the midpoints of other black squares using the side length of squares"""
        distMultiplier = 10 #Increasing this number makes the game easier
        desDist = int(distMultiplier*sqS)
        """"""

        """Store actual distance"""
        end = False
        if len(l) > 0:
            dist = l[0]
        else:
            end = True
            return True
        """"""
        
        """Compare distances"""
        if desDist < dist and not end:
            return False
        elif not end:
            return True

    def isValidBlue(self, pt, blacks, blues, sqS):

        """Returns a boolean of whether or not a point can be used as the midpoint of a blue square"""

        """Create a sorted list of distances between pt and the midpoints of black squares"""
        lBlack = []
        for point in blacks:
            lBlack.append(self.dist(pt,point))
        lBlack = sorted(lBlack)
        """"""

        """Create another sorted list of distances between pt and the midpoints of blue squares"""
        lBlue = []
        for point in blues:
            lBlue.append(self.dist(pt,point))
        lBlue = sorted(lBlue)
        """"""

        """Verify that the greatest distance between pt and a blue square and the shortest distance between pt and a black square are satisfactory"""
        dist = randrange(2,5) #Used to calculate desired distance from blue squares (see next line)

        """Calculate desired maximum distance from the midpoints of other blue squares using diff"""
        desBlueDist = int(self.s/dist)
        """"""

        """Calculate desired minimum distance from the midpoints of black squares by multiplying a number greater than 1 to the side length of squares"""
        distMultiplier = 3
        desBlackDist = int(distMultiplier*sqS) #desBlackDist must get a number greater than the length of the sides of the black squares
        """"""

        """Store actual distances"""
        end = False
        if len(lBlue) == 0:
            end = True
            return [True]
        else:
            maxBlueDist = lBlue[-1] #gets the last element of lBlue which is the list's max because it is sorted
            minBlackDist = lBlack[0] #gets the first element of lBlack which is the list's min because it is sorted
        """"""

        """Compare distances"""
        if (maxBlueDist > desBlueDist or minBlackDist < desBlackDist or pt in blues) and not end: #pt in blues
            return [False]
        elif not end:
            return [True, minBlackDist] #for the difficulty calculation in self.play()

    def pop(self, blueSqs, blueButts, ind):

        """When a line intersects a blue square"""
        
        temp = Rectangle(Point(0, self.s), Point(self.s, 0))
        temp.setFill("blue")
        temp.draw(self.win)
        sleep(0.2)
        temp.undraw()

        blueSqs[ind].undraw()
        blueSqs[ind].setFill("cyan")
        blueSqs[ind].draw(self.win)

        blueButts[ind].deactivate()
            
class Button:

    """From class, modified slightly"""
    
    def __init__(self, win, height,width, centerPt,label, color):
        x,y = centerPt.getX(), centerPt.getY()
        self.centerPt = centerPt
        self.xmax=x+width/2
        self.xmin=x-width/2
        self.ymax=y+height/2
        self.ymin=y-height/2
        self.rect=Rectangle(Point(self.xmin,self.ymin),Point(self.xmax,self.ymax))
        self.rect.setFill(color)
        self.rect.draw(win)
        self.label = Text(centerPt, label)
        self.label.setFill("cyan")
        if color == "green":
            self.label.setFill("black")
        self.label.draw(win)
        self.activate()

    def isClicked(self,pt):
        if self.active and self.xmin<= pt.getX() <= self.xmax and self.ymin <= pt.getY() <= self.ymax:
            return True
        else:
            return False
    def activate(self):
        """Sets this button to active"""
        self.active = True
       # self.rect.setWidth(2)
        #self.label.setFill('black')

    def deactivate(self):
        """Sets this button to inactive mode."""
        self.active= False
       # self.rect.setWidth(1)
       # self.label.setFill("gray")
        
    def setLabel(self, newLabel):
        """Mutator method"""
        self.label = newLabel
    def getLabel(self):
        return self.label
    
def main():
    s = 600 #side length of graphwin pypyBlek will be played in
    pypyBlek = PyBlek(s) #starts new game and takes user to start screen
main()
